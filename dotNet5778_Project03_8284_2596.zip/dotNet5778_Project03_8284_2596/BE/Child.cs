﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Child
    {
        private int id;
        public int Id
        {
            get { return id; }
            set
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                id = value;
            }
        }

        private int idMother;
        public int IdMother
        {
            get { return idMother; }
            set
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                idMother = value;
            }
        }

        public string FirstName
        {
            get; set;
        }
        public string LastName
        {
            get; set;
        }
        public DateTime BirthDate
        {
            get; set;
        }

        public bool BoolSpecialNeeds
        {
            get; set;
        }

        public string StringSpecialNeeds
        {
            get; set;
        }
        private string childBasicDetails;
        public string ChildBasicDetails
        {
            get { return childBasicDetails; }
            set{ childBasicDetails = value; }
        }
        public override string ToString()
        {
            string s=null;
            s += "Id: " + Id + "\n";
            s+="Id Mother: "+IdMother+ "\n";
            s += "First Name: " + FirstName+ "\n";
            s += "Last Name: " + LastName + "\n";
            s += "Birth Date: " +BirthDate.Day+"/"+ BirthDate.Month + "/"+ BirthDate.Year+ "\n Special Needs: ";
            if (!BoolSpecialNeeds)
            {
                s += "false\n";
                s += "StringSpecialNeeds: " + " \n";
            }
            else
            {
                s += "true\n";
                s += "StringSpecialNeeds: " +StringSpecialNeeds+ " \n";
            }
            return s;
        }
    }
}


