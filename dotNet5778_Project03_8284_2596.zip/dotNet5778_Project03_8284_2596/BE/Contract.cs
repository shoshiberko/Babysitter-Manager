﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BE
{
    public class Contract
    {
        public Contract()
        {
            WorkHours = new DateTime[2,6];
        }
        public static int staticNumOFContract =1;
        public int NumOFContract//a special number of 8 digits
        {
            get; set;
        }

        private int idNanny;
        public int IdNanny
        {
            get { return idNanny; }
            set
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                idNanny = value;
            }
        }

        private int idChild;
        public int IdChild
        {
            get { return idChild; }
            set
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                idChild = value;
            }
        }

        public bool BoolMeeting//=true if was a first meeting
        {
            get; set;
        }

        public bool Signature
        {
            get; set;
        }

        private float moneyForHour;
        public float MoneyForHour
        {
            get { return moneyForHour; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                moneyForHour = value;
            }
        }

        private float moneyForMonth;
        public float MoneyForMonth
        {
            get { return moneyForMonth; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                moneyForMonth = value;
            }
        }

        public EnumPayment TypeOfPayment//the type of the payment
        {
            get; set;
        }

        public DateTime StartDate
        {
            get; set;
        }

        public DateTime EndDate
        {
            get; set;
        }

        private string contractBasicDetails;
        public string ContractBasicDetails
        {
            get { return contractBasicDetails; }
            set { contractBasicDetails = value; }
        }

        public string NumOfContractString//numOfContract with 8 digits
        {
            get
            {
                string str = NumOFContract.ToString();
                string result = "";
                for (int i = 0; i < 8 - str.Count(); i++)
                {
                    result += "0";
                }
                result += str;
                return result;
            }
        }

        [XmlIgnore]
        public DateTime [,] WorkHours
        {
            get;set;
        }

        public string WorkHoursString
        {
            get {
                if (WorkHours == null)
                    return null;
                string result = "";
                int size1= WorkHours.GetLength(0);
                int size2 =WorkHours.GetLength(1);
                result += "" + size1 + "," + size2;

                for (int i = 0; i < size1; i++)
                    for (int j = 0; j < size2; j++)
                        result += "," + WorkHours[i, j].Hour+":"+WorkHours[i,j].Minute;
                return result;
            }
            set {
                if (value != null && value.Length > 0)
                {
                    string[] values = value.Split(',');
                    int size1 = int.Parse(values[0]);
                    int size2 = int.Parse(values[1]);

                    WorkHours = new DateTime[size1, size2];

                    int index = 2;
                    string []time;
                    for (int i = 0; i < size1; i++)
                        for (int j = 0; j < size2; j++)
                        {
                            time = values[index++].Split(':');
                            WorkHours[i, j] = new DateTime(2000,1,1,int.Parse(time[0]), int.Parse(time[1]),0);
                        }
                }
            }
        }
       
        public override string ToString()
        {
            string s = null;
            s += "Id Nanny: " + IdNanny + "\nId Child: "+IdChild+"\nStart Date: ";
            s += StartDate.Day + "/" + StartDate.Month + "/" + StartDate.Year + "\nEnd Date: ";
            s += EndDate.Day + "/" + EndDate.Month + "/" + EndDate.Year + "\nType Of Payment: "+TypeOfPayment+"\nIs Meeting: ";
            if (BoolMeeting)
                s += "true\nSignature: ";
            else
                s += "false\nSignature: ";
            if (Signature)
                s += "true\n";
            else
                s += "false\n";
            EnumDays day;
            s += "Hours:\n";
            for (int i = 0; i < 6; i++)

            { if (WorkHours[0, i] != WorkHours[1, i])
                {
                    day = (EnumDays)i;
                    s += day.ToString() + ": from ";
                    if (WorkHours[0, i].Hour < 10)
                        s += "0";
                    s += WorkHours[0, i].Hour.ToString() + ":";
                    if (WorkHours[0, i].Minute < 10)
                        s += "0";
                    s += WorkHours[0, i].Minute.ToString();
                    s += " to ";
                    if (WorkHours[1, i].Hour < 10)
                        s += "0";
                    s += WorkHours[1, i].Hour.ToString() + ":";
                    if (WorkHours[1, i].Minute < 10)
                        s += "0";
                    s += WorkHours[1, i].Minute.ToString() + "\n";
                }
                }
                s += "\n";
            return s;
        }
    }
}
