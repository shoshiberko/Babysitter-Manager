﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BE
{
    public class Mother
    {
        public Mother(/*int id*/)//ctor
        {
            //Id = id;
            needKeepingDays = new bool[6] { false, false, false, false, false, false };
            wantedWorkHours = new DateTime[2, 6];
        }

        private int id;
        public int Id
        {
            get { return id; }
            set////
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                id = value;
            }
        }

        public string FirstName
        {
            get; set;
        }

        public string LastName
        {
            get; set;
        }
        private string phone;
        public string Phone
        {
            get { return phone; }
            set
            {
                int temp;
                string[] help = value.Split('-');
                if (help.Count() > 2)
                    throw new Exception("this phone is not legal");
                for (int i = 0; i < help.Count(); i++)
                {
                    try
                    {
                        temp = int.Parse(help[i]);
                    }
                    catch
                    {
                        throw new Exception("this phone is not legal");
                    }
                }
                phone = value;
            }
        }

        public string Address
        {
            get; set;
        } = "";

        public string AddressForNanny
        {
            get; set;
        } = "";

        public string Comments
        {
            get; set;
        }

        public string mailAddress
        {
            get;set;
        }

        public bool[] needKeepingDays///////ז. מאפיין שהוא מערך בוליאני שכל איבר מציין יום ובו שומרים אם האם צריכה מטפלת ביום זה או
        {
            get; set;
        }

        [XmlIgnore]
        public DateTime[,] wantedWorkHours///////a matrix, 6 colomns for 6 days, 2 lines for the hours that the wanted hours to keep: the first to start and the second for end
        {
            get; set;
        }

        public string WorkHoursString
        {
            get
            {
                if (wantedWorkHours == null)
                    return null;
                string result = "";
                int size1 = wantedWorkHours.GetLength(0);
                int size2 = wantedWorkHours.GetLength(1);
                result += "" + size1 + "," + size2;

                for (int i = 0; i < size1; i++)
                    for (int j = 0; j < size2; j++)
                        result += "," + wantedWorkHours[i, j].Hour + ":" + wantedWorkHours[i, j].Minute;
                return result;
            }
            set
            {
                if (value != null && value.Length > 0)
                {
                    string[] values = value.Split(',');
                    int size1 = int.Parse(values[0]);
                    int size2 = int.Parse(values[1]);

                    wantedWorkHours = new DateTime[size1, size2];

                    int index = 2;
                    string[] time;
                    for (int i = 0; i < size1; i++)
                        for (int j = 0; j < size2; j++)
                        {
                            time = values[index++].Split(':');
                            wantedWorkHours[i, j] = new DateTime(2000, 1, 1, int.Parse(time[0]), int.Parse(time[1]), 0);
                        }
                }
            }
        }

        public string MotherDetails { get { return ("Id: " + id.ToString() + " " + " Name: " + FirstName+" " + LastName); } }
        public override string ToString()
        {
            EnumDays day;
            string s = null;
            s += "Id: " + Id + "\nFirst Name: " + FirstName + "\nLast Name:" + LastName + "\nPhone: "+Phone+ "\nAddress: "+Address;
            s += "\nAddress For Nanny: " + AddressForNanny + "\nComments: "+Comments+ "\nMail Address: "+mailAddress;
            s += "\nNeed Keeping Days:\n";
            for (int i = 0; i < 6; i++)
            {
                day = (EnumDays)i;
                s += day.ToString() + ": " + needKeepingDays[i].ToString() + " ";
            }
            s += "\nWanted Work Hours:\n";
            for (int i = 0; i < 6; i++)
            {
                if (needKeepingDays[i])
                {
                    day = (EnumDays)i;
                    s += day.ToString() + ": from ";
                    if (wantedWorkHours[0, i].Hour < 10)
                        s += "0";
                    s += wantedWorkHours[0, i].Hour.ToString() + ":";
                    if (wantedWorkHours[0, i].Minute < 10)
                        s +="0";
                    s+= wantedWorkHours[0, i].Minute.ToString();
                     s += " to ";
                    if (wantedWorkHours[1, i].Hour < 10)
                        s += "0";
                    s += wantedWorkHours[1, i].Hour.ToString() + ":";
                    if (wantedWorkHours[1, i].Minute < 10)
                        s += "0";
                    s += wantedWorkHours[1, i].Minute.ToString()+ "  ";
                }
            }
            s += "\n";
            return s;
        }

    }

}
