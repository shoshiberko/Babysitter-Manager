﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BE
{
    public class Nanny
    {
        public Nanny()
        {
            keepingDays = new bool[6] { false, false, false, false, false, false };
            workHours = new DateTime[2, 6];
        }
        private int id;
        public int Id
        {
            get { return id; }
            set
            {
                if (value < 0)
                    throw new Exception("this id is not legal");
                id = value;
            }
        }

        public string FirstName
        {
            get; set;
        }

        public string LastName
        {
            get; set;
        }

        public DateTime BirthDate
        {
            get; set;
        }
        private string phone;
        public string Phone
        {
            get { return phone; }
            set
            {
                int temp;
                string[] help = value.Split('-');
                if(help.Count()>2)
                    throw new Exception("this phone is not legal");
                for (int i = 0; i < help.Count(); i++)
                {
                    try
                    {
                        temp = int.Parse(help[i]);
                    }
                    catch
                    {
                        throw new Exception("this phone is not legal");
                    }
                }
                phone = value;
            }
        }

        public string Address
        {
            get; set;
        } = "";

        public bool Elevator
        {
            get; set;
        }

        private int floor;
        public int Floor
        {
            get { return floor; }
            set
            {
                if (value < 0)
                    throw new Exception("this number of floor is not legal");
                floor = value;
            }
        }

        private float experienceYears;
        public float ExperienceYears
        {
            get { return experienceYears; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                experienceYears = value;
            }
        }

        private int numOfChildren;
        public int NumOfChildren//addition 
        {
            get { return numOfChildren; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                numOfChildren = value;
            }
        }

        private int maxChildrens;
        public int MaxChildrens
        {
            get { return maxChildrens; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                maxChildrens = value;
            }
        }

        private float minChildrens;
        public float MinMonthesAge
        {
            get { return minChildrens; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                minChildrens = value;
            }
        }

        private float maxMonthesAge;
        public float MaxMonthesAge
        {

            get { return maxMonthesAge; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                maxMonthesAge = value;
            }
        }

        public bool BoolMoneyForHour
        {
            get; set;
        }

        private float moneyForHour;
        public float MoneyForHour
        {
            get { return moneyForHour; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                moneyForHour = value;
            }
        }

        private float moneyForMonth;
        public float MoneyForMonth
        {
            get { return moneyForMonth; }
            set
            {
                if (value < 0)
                    throw new Exception("this number is not legal");
                moneyForMonth = value;
            }
        }

        public bool VacationByEducationOffice//מאפיין בוליאני שמציין האם ימי החופשה שהמטפלת דורשת מבוססים ע"פ ימי החופשה של משרד
                                             //החינוך או ימי החופשה של משרד תעשיה-מסחר-ותעסוקה )תמ"ת(./*
        {
            get; set;
        }

        public string Recommendations
        {
            get; set;
        }

        public string mailAddress
        {
            get; set;
        }

        public int Rate
        {
            get;set;
        }

        public string NannyDetails
        {
            get { return ("Id: " + Id + " Name: " + FirstName + " " + LastName); }
        }

        public bool[] keepingDays///////
        {
            get; set;
        }

        [XmlIgnore]
        public DateTime[,] workHours///////a matrix, 6 colomns for 6 days, 2 lines, 1 for start and the second for end
        {
            get; set;
        }
        
        public string WorkHoursString
        {
            get
            {
                if (workHours == null)
                    return null;
                string result = "";
                int size1 = workHours.GetLength(0);
                int size2 = workHours.GetLength(1);
                result += "" + size1 + "," + size2;

                for (int i = 0; i < size1; i++)
                    for (int j = 0; j < size2; j++)
                        result += "," + workHours[i, j].Hour + ":" + workHours[i, j].Minute;
                return result;
            }
            set
            {
                if (value != null && value.Length > 0)
                {
                    string[] values = value.Split(',');
                    int size1 = int.Parse(values[0]);
                    int size2 = int.Parse(values[1]);

                    workHours = new DateTime[size1, size2];

                    int index = 2;
                    string[] time;
                    for (int i = 0; i < size1; i++)
                        for (int j = 0; j < size2; j++)
                        {
                            time = values[index++].Split(':');
                            workHours[i, j] = new DateTime(2000, 1, 1, int.Parse(time[0]), int.Parse(time[1]), 0);
                        }
                }
            }
        }


        public override string ToString()
        {
            string s = null;
            s += "Id: " + Id + "\nFirst Name: " + FirstName + "\nLast Name:" + LastName + "\nBirth Date: " + BirthDate.Day + "/" + BirthDate.Month + "/" + BirthDate.Hour + "\n";
            s += "Phone: " + Phone + "\nAddress: " + Address + "\nExperienceYears: " + ExperienceYears + "\nMax Children: " + MaxChildrens + "\nNum Of Children: " + NumOfChildren + "\n";
            s += "Min Monthes Age: " + MinMonthesAge + "\nMax Monthes Age: " + MaxMonthesAge + "\nMoney For Hour: ";
            if (BoolMoneyForHour)
                s += "true\nMoney For Hour: "+MoneyForHour+ "\nVacation By Tamat Office: ";
            else
                s +="false\nMoney For Month: " + MoneyForMonth + "\nVacation By Tamat Office: ";
            if (VacationByEducationOffice)
                s += "true\nFloor: ";
            else
                s += "false\nFloor: ";
            s += Floor+"\nElevator: ";
            if (Elevator)
                s += "true\n";
            else
                s += "false\n";
            EnumDays day;
            //string s = ToStringClass.ToStringProperty(this);
            s += "keepingDays:\n";
            for (int i = 0; i < 6; i++)
            {
                day = (EnumDays)i;
                s += day.ToString() + ": " + keepingDays[i].ToString() + " ";
            }
            s += "\nworkHours:\n";
            for (int i = 0; i < 6; i++)
            {
                if (keepingDays[i])
                {
                    day = (EnumDays)i;
                    s += day.ToString() + ": from ";
                    if (workHours[0, i].Hour < 10)
                        s += "0";
                    s += workHours[0, i].Hour.ToString() + ":";
                    if (workHours[0, i].Minute < 10)
                        s += "0";
                    s += workHours[0, i].Minute.ToString();
                    s += " to ";
                    if (workHours[1, i].Hour < 10)
                        s += "0";
                    s += workHours[1, i].Hour.ToString() + ":";
                    if (workHours[1, i].Minute < 10)
                        s += "0";
                    s += workHours[1, i].Minute.ToString() + "  ";
                }
            }
            s += "\nRecommendations: ";
            s += Recommendations + "\n";
            s += "Mail Address: " + mailAddress + "\n";
            s += "Rating: " + Rate + " stars\n";
            return s;
        }

    }
}

