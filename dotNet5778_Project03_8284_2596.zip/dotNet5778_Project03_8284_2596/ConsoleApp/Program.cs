﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
using BE;
namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            IBL bl;
                try
                {
                    bl = new imp_BL();
                    DateTime d = new DateTime(2000, 1, 1, 8, 20, 0);

                    bool[] helpkeepingDays = new bool[6] { true, false, true, false, true, true };
                    DateTime[,] helpworkHours = new DateTime[2, 6];
                    for (int i = 0; i < 6; i++)
                    {
                        helpworkHours[0, i] = new DateTime(2000, 1, 1, 7, 0, 0);
                        helpworkHours[1, i] = new DateTime(2000, 1, 1, 15, 30, 0);
                    }

                    bl.AddNanny(new Nanny()
                    {
                        Id =167,
                        FirstName = "Dina",
                        LastName = "Simon",
                        BirthDate = new DateTime(1998, 6, 23),
                        Phone = "0535732453",
                        Address = "Nachal Gilo,Beit Shemesh,Isreal",
                        Elevator = true,
                        Floor = 3,
                        ExperienceYears = 2,
                        NumOfChildren = 0,
                        MaxChildrens = 6,
                        MinMonthesAge = 10,
                        MaxMonthesAge = 56,
                        BoolMoneyForHour = true,
                        MoneyForHour = 50,
                        MoneyForMonth = 2000,
                        keepingDays = helpkeepingDays,
                        workHours = helpworkHours,
                        VacationByEducationOffice = false,
                        Recommendations = ""
                    });
                DateTime d1 = new DateTime(2000, 1, 1, 8, 20, 0);

                bool[] helpkeepingDays1 = new bool[6] { true, true, true, true, true, false };
                DateTime[,] helpworkHours1 = new DateTime[2, 6];
                for (int i = 0; i < 6; i++)
                {
                    helpworkHours1[0, i] = new DateTime(2000, 1, 1, 8, 0, 0);
                    helpworkHours1[1, i] = new DateTime(2000, 1, 1, 9, 30, 0);
                }

                bl.AddNanny(new Nanny()
                {
                    Id =7,
                    FirstName = "Chana",
                    LastName = "Hazan",
                    BirthDate = new DateTime(1982,5, 6),
                    Phone = "0545782345",
                    Address = "Ben Gurion,Kiryat Malachi,Isreal",
                    Elevator = false,
                    Floor = 3,
                    ExperienceYears = 10,
                    NumOfChildren = 0,
                    MaxChildrens = 10,
                    MinMonthesAge = 10,
                    MaxMonthesAge = 46,
                    BoolMoneyForHour = true,
                    MoneyForHour = 50,
                    MoneyForMonth = 2000,
                    keepingDays = helpkeepingDays1,
                    workHours = helpworkHours1,
                    VacationByEducationOffice = false,
                    Recommendations = ""
                });
                bool[] helpkeepingDays2 = new bool[6] { true, true, false, true, true, false };
                    DateTime[,] helpworkHours2 = new DateTime[2, 6];
                    for (int i = 0; i < 6; i++)
                    {
                        helpworkHours2[0, i] = new DateTime(2000, 1, 1,8, 0, 0);
                        helpworkHours2[1, i] = new DateTime(2000, 1, 1, 16, 0, 0);
                    }

                   bl.AddMother(new Mother()
                    {Id=5,
                        FirstName = "Dalia",
                        LastName = "Danino",
                        Phone = "0593275643",
                        Address = "Yafo,Jerusalem,Isreal",
                        AddressForNanny = "Nachal Katlav,Beit Shemesh,Isreal",
                        needKeepingDays = helpkeepingDays2,
                        wantedWorkHours = helpworkHours2,
                        Comments = "my child need to sleep between 14:00 to 16:00"
                    });
                    bl.AddChild(new Child()
                    {Id=9,
                    IdMother=5,
                        FirstName = "Dani",
                        BirthDate = new DateTime(2016, 7, 10),
                        BoolSpecialNeeds = true,
                        StringSpecialNeeds = "need to sleep between 14:00 to 16:00"
                    });
                Console.WriteLine("Get all the nannies that match to spesific mother needs:");
                foreach (var item in bl.getAllWantedNannies(bl.GetMother(5)))
                {
                    Console.WriteLine(item.ToString());
                }

                bl.AddContract(new Contract
                {
                    IdNanny = 7,
                    IdChild = 9,
                    BoolMeeting = true,
                    Signature = true,
                    TypeOfPayment = (EnumPayment)1,
                    StartDate = new DateTime(2017, 12, 12),
                    EndDate = new DateTime(2018, 12, 12)
                });
                bl.AddChild(new Child()
                {Id=9887,
                IdMother=5,
                    FirstName = "Shimi",
                    BirthDate = new DateTime(2016, 12, 12),
                    BoolSpecialNeeds = false,
                    StringSpecialNeeds = ""
                });
                bl.AddContract(new Contract
                {
                    IdNanny = 7,
                    IdChild = 9887,
                    BoolMeeting = true,
                    Signature = true,
                    TypeOfPayment = (EnumPayment)1,
                    StartDate = new DateTime(2017, 12, 12),
                    EndDate = new DateTime(2018, 6, 12)
                });
                bl.AddMother(new Mother()
                {Id=665,
                    FirstName = "Shoshi",
                    LastName = "Berko",
                    Phone = "0599975643",
                    Address = "Yafo,Jerusalem,Isreal",
                    AddressForNanny = "Nachal Katlav,Beit Shemesh,Isreal",
                    needKeepingDays = helpkeepingDays2,
                    wantedWorkHours = helpworkHours2,
                    Comments = "my child need to sleep between 14:00 to 16:00"
                });
                bl.AddChild(new Child()
                {Id=222,
                IdMother=665,
                    FirstName = "David",
                    BirthDate = new DateTime(2015, 7, 10),
                    BoolSpecialNeeds = false,
                    StringSpecialNeeds = ""
                });
                Console.WriteLine("Get a nanny from her Id:");
                Console.WriteLine(bl.GetNanny(1));
                Console.WriteLine("Remove Contract according it number:");
                bl.RemoveContract(1);
                Console.WriteLine("Get all the children of spesific nanny that had Birthday in this month:");
                foreach (var item in bl.getAllMonthBirthdayChild(bl.GetNanny(7)))
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get all the children of spesific nanny");
                foreach (var item in bl.GetAllChildOfNanny(bl.GetNanny(7)))
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get a contract by it's number:");
                Console.WriteLine(bl.GetContract(3));
                Console.WriteLine("Get a mother by it's Id:");
                Console.WriteLine(bl.GetMother(5));
                Console.WriteLine("Get all the nannies:");
                foreach (var item in bl.GetAllNanny())
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get 5 best match nannies:");
                foreach (var item in bl.get5BestMatchNannies(bl.GetMother(5)))
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get all the children without nanny:");
                foreach (var item in bl.getAllChildWithoutNanny())
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get all nannies that their vacation by Tamat Office:");
                foreach (var item in bl.getAllNannyVacationByTamatOffice())
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get all contract according to a spesific delegate:");
                foreach (var item in bl.getAllContractAccordingDelegate(co => bl.DaysToEndOfContract(co) < 355))
                {
                    Console.WriteLine(item.ToString());
                }
                Console.WriteLine("Get number of all contract according to a spesific delegate:");
                Console.WriteLine(bl.getNumContractAccordingDelegate(co => bl.DaysToEndOfContract(co) < 355).ToString());

                float dis = bl.distance(bl.GetMother(5).AddressForNanny, bl.GetNanny(7).Address);
                Console.WriteLine(dis);

                Console.WriteLine("Get Grouping of contract by distance:");
                foreach (var item in bl.GroupingContractByDistance(true))
                {
                    Console.WriteLine(item.Key.ToString());
                    foreach (var n in item)
                    {
                        Console.WriteLine(n.ToString());
                    }
                }
                Console.WriteLine("Get Grouping of nanny by age of child(min or max):");
                foreach (var item in bl.GroupingNannyByAge(true,true))
                {
                    Console.WriteLine(item.Key.ToString());
                    foreach (var n in item)
                    {
                        Console.WriteLine(n.ToString());
                    }
                }
                Console.WriteLine("Get string of all the children's special need:(children of spesific nanny)");
                Console.WriteLine(bl.ChildSpecialNeeds(bl.GetNanny(7)));
                Console.WriteLine("Get string of all the children's mothers Phones:(children of spesific nanny)");
                Console.WriteLine(bl.MothersPhones(bl.GetNanny(7)));
                Console.WriteLine("Get string of all the children's mothers comments:(children of spesific nanny)");
                Console.WriteLine(bl.MothersComments(bl.GetNanny(1)));
                Console.WriteLine("Get all children of spesific nanny:");
                
                foreach (var item in bl.GetAllChildOfNanny(bl.GetNanny(7)))
                {
                    Console.WriteLine(item);

                }
                Console.WriteLine("בדיקהההההההה");
                foreach (var item in bl.GetAllContract())
                {
                    Console.WriteLine(item);

                }
                bl.RemoveContract(2);
                Console.WriteLine("אחרי מחיקה:");
                foreach (var item in bl.GetAllContract())
                {
                    Console.WriteLine(item);

                }
                bl.RemoveContract(2);
            }
            catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }

            }
        }
    }

