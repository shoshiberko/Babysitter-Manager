﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;
using System.ComponentModel;
using System.Threading;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for GroupingWindow.xaml
    /// </summary>
    public partial class GroupingWindow : Window
    {
        IBL bl;
        public GroupingWindow()
        {
            InitializeComponent();
            bl = FactoryBL.GetBL();
        }

        /// <summary>
        /// get all the nannies to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allNanniesMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingUser = new UserControlGetAll();
                groupingUser.label.Content = "All Nannies";
               // groupingUser.label.FontSize = 30;
                this.page.Content = groupingUser;
                groupingUser.listView.ItemsSource = bl.GetAllNanny();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        ///click nannyMinAgeMenuItem - group all the nanny by min age property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nannyMinAgeMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGrouping groupingNanny = new UserControlGrouping();
                groupingNanny.label.Content = "Grouping nannies by min child age";
                this.page.Content = groupingNanny;
                groupingNanny.Source = (bl.GroupingNannyByAge(false, true));

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click nannyMaxAgeMenuItem - group all the nanny by max age property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nannyMaxAgeMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGrouping groupingNanny = new UserControlGrouping();
                groupingNanny.label.Content = "Grouping nannies by max child age";
                this.page.Content = groupingNanny;
                groupingNanny.Source = (bl.GroupingNannyByAge(true, true));

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click allMothersMenuItem - get all the mothers to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allMothersMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingUser = new UserControlGetAll();
                groupingUser.label.Content = "All Mothers";
                this.page.Content = groupingUser;
                groupingUser.listView.ItemsSource = bl.GetAllMother();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click allChildrenMenuItem - get all the children to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allChildrenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingUser = new UserControlGetAll();
                groupingUser.label.Content = "All Children";
                this.page.Content = groupingUser;
                groupingUser.listView.ItemsSource = bl.GetAllChild();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click allContractMenuItem - get all the contract to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allContractsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingUser = new UserControlGetAll();
                groupingUser.label.Content = "All Contracts";
                this.page.Content = groupingUser;
                groupingUser.listView.ItemsSource = bl.GetAllContract();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click allChildrenWithoutNanny - get all the children without nanny to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allChildrenWithoutNannyMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingChild = new UserControlGetAll();
                groupingChild.label.Content = "All Children without nanny";
                this.page.Content = groupingChild;
                groupingChild.Source = (bl.getAllChildWithoutNanny());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click allNanniesVactionMenuItem - get all the nannies vacation by TamatOffice to the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allNanniesVactionMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserControlGetAll groupingNanny = new UserControlGetAll();
                groupingNanny.label.Content = "All Nannies Vaction according Tamat Office";
                this.page.Content = groupingNanny;
                groupingNanny.Source = (bl.getAllNannyVacationByTamatOffice());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// group all the contract by distance (km) to the page
        /// </summary>
        /// <param name="grouping"></param>
        public void Act(List<IGrouping<float, Contract>> grouping)
        {
            try
            {
                UserControlGrouping groupingContract = new UserControlGrouping();
                // List<IGrouping<float, Contract>> lst = grouping.ToList();
                groupingContract.label.Content = "Grouping contracts by distance";
                this.page.Content = groupingContract;
                groupingContract.Source = grouping;
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }
         }

        /// <summary>
        /// click GroupingContractDistanceMenuItem- group all the contract by distance (km) to the page(by thread)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GroupingContractDistanceMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Thread t = new Thread(
                () =>
                {
                    try
                    { //float dis = bl.distance(bl.GetMother(2).AddressForNanny, bl.GetNanny(1).Address);
                        var v = ((bl.GroupingContractByDistance(true)));
                        //Action<IEnumerable<IGrouping<float, Contract>>> a = Act;
                        //Dispatcher.BeginInvoke(a, v);
                        Action<List<IGrouping<float, Contract>>> a = Act;
                        Dispatcher.BeginInvoke(a, v.ToList());
                    }
                    catch(Exception E)
                    {
                        MessageBox.Show(E.Message);
                    }
                });
            t.Start();
        }
        
    }
}

