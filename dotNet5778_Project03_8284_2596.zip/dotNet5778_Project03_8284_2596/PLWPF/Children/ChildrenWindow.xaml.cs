﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BL;
using BE;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for ChildrenWindow.xaml
    /// </summary>
    public partial class ChildrenWindow : Window
    {
        IBL bl;
        public Child childToAdd;
        public Child childToUpdate;
        private List<string> AddErrorMessages;
        private List<string> UpdateErrorMessages;
        public ChildrenWindow()
        {
            try
            {
                InitializeComponent();
                bl = FactoryBL.GetBL();
                childToAdd = new BE.Child();
                childToUpdate = new BE.Child();
                childToAdd.BirthDate = DateTime.Now;
                childToUpdate.BirthDate = DateTime.Now;
                AddErrorMessages = new List<string>();
                UpdateErrorMessages = new List<string>();
                UpdateGrid.DataContext = childToUpdate;
                AddGrid.DataContext = childToAdd;
                //refresh all the combobox
                refreshUpdateComboBox();
                refreshDeleteComboBox();
                refreshAddComboBox();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        void refreshDeleteComboBox()//refresh the combo box of delete tab
        {
            this.DeleteComboBox.ItemsSource = bl.GetAllChild();
            this.DeleteComboBox.DisplayMemberPath = "ChildBasicDetails";
            this.DeleteComboBox.SelectedValuePath = "Id";
        }
        void refreshAddComboBox()//refresh the combo box of add tab
        {
            this.idMotherComboBox1.ItemsSource = bl.GetAllMother();
            this.idMotherComboBox1.DisplayMemberPath = "MotherDetails";
        }
        void refreshUpdateComboBox()//refresh the combo box of update tab
        {
            this.idComboBox.ItemsSource = bl.GetAllChild();
            this.idComboBox.DisplayMemberPath = "ChildBasicDetails";
            this.idComboBox.SelectedValuePath = "Id";
        }
        public void refresh()//refresh all the combo box
        {
            this.idComboBox.ItemsSource = null;
            this.idMotherComboBox1.ItemsSource = null;
            this.DeleteComboBox.ItemsSource = null;
            this.DeleteComboBox.ItemsSource = bl.GetAllChild();
            this.idMotherComboBox1.ItemsSource = bl.GetAllMother();
            this.idComboBox.ItemsSource = bl.GetAllChild();
        }
        int GetIdComboBox(object sender, RoutedEventArgs e)//return id of the selected item
        {
            object result = this.DeleteComboBox.SelectedValue;
            if (result == null)
                throw new Exception("must select Child First");
            return (int)result;
        }
        private Child getCopy(Child ch)//copies child (by value copy)
        {
            if (ch == null)
                return null;
            return (new Child()
            {
                Id = ch.Id,
                IdMother = ch.IdMother,
                FirstName = ch.FirstName,
                BirthDate = ch.BirthDate,
                BoolSpecialNeeds = ch.BoolSpecialNeeds,
                StringSpecialNeeds = ch.StringSpecialNeeds,
                ChildBasicDetails = ch.ChildBasicDetails
            });
        }
        private void DeleteChild_Click(object sender, RoutedEventArgs e)//delete child click
        {

            try
            {
                //ask the user if he is sure with the removing
                MessageBoxResult result = MessageBox.Show((bl.GetChild(GetIdComboBox(this, null)).ToString()) +
                                              "\nAre you sure you want to delete this child?\n", "Warnning!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes://the user press yes, delets the selected child
                        bl.RemoveChild(GetIdComboBox(this, null));
                        MessageBox.Show("the child removed");
                        refresh();
                        break;
                    default://else
                        break;
                }
                
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }

        }
        private void addChildButton_Click(object sender, RoutedEventArgs e)//add child click
        {
            try
            {
                if (idMotherComboBox1.SelectedItem == null)//the user does not select any child
                    throw new Exception("must fill all the details!");
                childToAdd.IdMother = (idMotherComboBox1.SelectedItem as Mother).Id;//add id mothe from the combo box
                bl.AddChild(childToAdd);
                MessageBox.Show("the child is added");
                
                //refresh the window
                childToAdd = new BE.Child();
                childToAdd.BirthDate = DateTime.Now;
                AddGrid.DataContext = childToAdd;
                refresh();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        
        private void updateChildButton_Click(object sender, RoutedEventArgs e)//update child click
        {

            try
            {
                if (idComboBox.SelectedItem == null)//if the user does not select any choice in the combo box
                    throw new Exception("must select Child first");//
                if (childToUpdate!=null)
                    bl.UpdateChild(childToUpdate);

                MessageBox.Show("the child is updated");
                //refresh
                refresh();
                childToUpdate = new Child();
                childToUpdate.BirthDate = DateTime.Now;
                UpdateGrid.DataContext = childToUpdate;
            }
            catch (Exception E)
            {

                MessageBox.Show(E.Message);
            }

        }

        private void idComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//selection change event of the combo box of the update
           //where the user selects a child, it put his details on the window
        {
            Child c = idComboBox.SelectedItem as Child;//c is the choice of user
            try
            {
                if (c != null)
                {
                    childToUpdate = getCopy(c);
                    UpdateGrid.DataContext = childToUpdate;//the data context for the binding is the copy of the choice
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void Add_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                AddErrorMessages.Add(e.Error.Exception.Message);
            else
                AddErrorMessages.Remove(e.Error.Exception.Message);
            this.addChildButton.IsEnabled = !AddErrorMessages.Any();
        }

        private void Update_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                UpdateErrorMessages.Add(e.Error.Exception.Message);
            else
                UpdateErrorMessages.Remove(e.Error.Exception.Message);
            this.UpdateChildButton.IsEnabled = !UpdateErrorMessages.Any();
        }
    }
}
