﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BL;
using BE;
using System.Threading;
using System.Windows.Threading;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IBL bl;
        DispatcherTimer timer = null;
        DispatcherTimer stopTimer = null;
        public MainWindow()
        {
            try
            {
                InitializeComponent();
                bl = FactoryBL.GetBL();
                //show all the contracts that  are expired by compare to the date now
                var temp = bl.GetAllContract(co => ((co.EndDate.Year < DateTime.Now.Year) || ((co.EndDate.Year == DateTime.Now.Year) && (co.EndDate.Month < DateTime.Now.Month)) || ((co.EndDate.Year == DateTime.Now.Year) &&
                            (co.EndDate.Month == DateTime.Now.Month) && (co.EndDate.Day < DateTime.Now.Day))));
                string expiredContractsString = "Pay Attention!!! The following contracts are expired:\n";
                foreach (var item in temp)
                {
                    expiredContractsString += item.ContractBasicDetails + "\nstart date: " + item.StartDate.Day + "/" + item.StartDate.Month + "/" + item.StartDate.Year + " end date: " + item.EndDate.Day + "/" + item.EndDate.Month + "/" + item.EndDate.Year + "\n";
                }
                expiredContractsString += "\nDo you want to delete these contracts?\n";
                MessageBoxResult result;
                if (temp.ToList().Count != 0)
                {
                    result = MessageBox.Show(expiredContractsString, "Warnning!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                    switch (result)
                    {
                        case MessageBoxResult.Yes:
                            List<Contract> lst = temp.ToList();
                            for (int i = 0; i < lst.Count; i++)//deletes the expired contracts
                                bl.RemoveContract(lst[i].NumOFContract);

                            break;
                        default:
                            break;
                    }
                }
                StartTimer();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //timer for the commercial 
        void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += new EventHandler(timer_Elapsed);
            timer.Start();
            stopTimer = new DispatcherTimer();
            stopTimer.Interval = TimeSpan.FromSeconds(23.5);
            stopTimer.Tick += new EventHandler(stopTimer_Elapsed);
            stopTimer.Start();
        }

        /// <summary>
        /// when the timer finish the interval, starts the comercial
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Elapsed(object sender, EventArgs e)
        {
            timer.Stop();
            popUpWindow.IsOpen = true;
            media.Play();
        }

        /// <summary>
        /// when the stoptimer finish the interval, stop the comercial
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void stopTimer_Elapsed(object sender, EventArgs e)
        {
            stopTimer.Stop();
            popUpWindow.IsOpen = false;
            media.Stop();
        }

        /// <summary>
        /// click contract button- open contract window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Contract_click(object sender, RoutedEventArgs e)
        {
            try
            {
                ContractsWindow cw = new ContractsWindow();
                cw.TabControl.SelectedIndex = 2;
                cw.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        /// <summary>
        /// click Nanny button- open nanny window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Nanny_click(object sender, RoutedEventArgs e)
        {
            try
            {
                NanniesWindow nw = new NanniesWindow();
                nw.TabControl.SelectedIndex = 2;
                nw.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click children button- open children window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Children_click(object sender, RoutedEventArgs e)
        {
            try
            {
                ChildrenWindow cw = new ChildrenWindow();
                cw.TabControl.SelectedIndex = 2;
                cw.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click mother button- open mother window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Mother_click(object sender, RoutedEventArgs e)
        {
            try
            {
                MothersWindow mw = new MothersWindow();
                mw.TabControl.SelectedIndex = 2;
                mw.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// click managing button- open "grouping" window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Grouping_Click(object sender, RoutedEventArgs e)
        {
            new GroupingWindow().ShowDialog();
        }
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            if (popUpWindow.IsOpen)
            {
                stopTimer.Stop();
                media.Stop();
                popUpWindow.IsOpen = false;
            }
        }
    }
}
