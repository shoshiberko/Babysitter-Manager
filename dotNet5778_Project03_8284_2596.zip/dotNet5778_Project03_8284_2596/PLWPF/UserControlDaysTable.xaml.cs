﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UserControlDaysTable.xaml
    /// </summary>
    public partial class UserControlDaysTable : UserControl
    {
        public UserControlDaysTable()
        {
            InitializeComponent();
            RefreshAll();
        }
        public void RefreshAll()
        {
            foreach (var item in this.HoursGrid.Children)
            {
                if (item is CheckBox)
                {
                    (item as CheckBox).IsChecked = false;
                }
            }
            StartSundayMinute.ItemsSource = null;
            EndSundayMinute.ItemsSource = null;
            StartMondayMinute.ItemsSource = null;
            EndMondayMinute.ItemsSource = null;
            StartTuesdayMinute.ItemsSource = null;
            EndTuesdayMinute.ItemsSource = null;
            StartWednesdayMinute.ItemsSource = null;
            EndWednesdayMinute.ItemsSource = null;
            StartThursdayMinute.ItemsSource = null;
            EndThursdayMinute.ItemsSource = null;
            StartFridayMinute.ItemsSource = null;
            EndFridayMinute.ItemsSource = null;

            StartSundayHour.ItemsSource = null;
            EndSundayHour.ItemsSource = null;
            StartMondayHour.ItemsSource = null;
            EndMondayHour.ItemsSource = null;
            StartTuesdayHour.ItemsSource = null;
            EndTuesdayHour.ItemsSource = null;
            StartWednesdayHour.ItemsSource = null;
            EndWednesdayHour.ItemsSource = null;
            StartThursdayHour.ItemsSource = null;
            EndThursdayHour.ItemsSource = null;
            StartFridayHour.ItemsSource = null;
            EndFridayHour.ItemsSource = null;


            string[] arrMinute = new string[60];
            for (int i = 0; i < 60; i++)
            {
                if (i < 10)
                    arrMinute[i] = "0" + i;
                else
                    arrMinute[i] = "" + i;
            }

            StartSundayMinute.ItemsSource = arrMinute;
            EndSundayMinute.ItemsSource = arrMinute;
            StartMondayMinute.ItemsSource = arrMinute;
            EndMondayMinute.ItemsSource = arrMinute;
            StartTuesdayMinute.ItemsSource = arrMinute;
            EndTuesdayMinute.ItemsSource = arrMinute;
            StartWednesdayMinute.ItemsSource = arrMinute;
            EndWednesdayMinute.ItemsSource = arrMinute;
            StartThursdayMinute.ItemsSource = arrMinute;
            EndThursdayMinute.ItemsSource = arrMinute;
            StartFridayMinute.ItemsSource = arrMinute;
            EndFridayMinute.ItemsSource = arrMinute;

            string[] arrHour = new string[24];
            for (int i = 0; i < 24; i++)
            {
                if (i < 10)
                    arrHour[i] = "0" + i;
                else
                    arrHour[i] = "" + i;
            }
            StartSundayHour.ItemsSource = arrHour;
            EndSundayHour.ItemsSource = arrHour;
            StartMondayHour.ItemsSource = arrHour;
            EndMondayHour.ItemsSource = arrHour;
            StartTuesdayHour.ItemsSource = arrHour;
            EndTuesdayHour.ItemsSource = arrHour;
            StartWednesdayHour.ItemsSource = arrHour;
            EndWednesdayHour.ItemsSource = arrHour;
            StartThursdayHour.ItemsSource = arrHour;
            EndThursdayHour.ItemsSource = arrHour;
            StartFridayHour.ItemsSource = arrHour;
            EndFridayHour.ItemsSource = arrHour;

        }
        /// <summary>
        /// event when CheckBox1 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            StartSundayHour.SelectedItem = null;
            StartSundayMinute.SelectedItem = null;
            EndSundayHour.SelectedItem = null;
            EndSundayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox1 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox1_Checked(object sender, RoutedEventArgs e)
        {
            StartSundayHour.SelectedItem = "00";
            StartSundayMinute.SelectedItem = "00";
            EndSundayHour.SelectedItem = "00";
            EndSundayMinute.SelectedItem = "00";
        }

        /// <summary>
        /// event when CheckBox2 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox2_Unchecked(object sender, RoutedEventArgs e)
        {
            StartMondayHour.SelectedItem = null;
            StartMondayMinute.SelectedItem = null;
            EndMondayHour.SelectedItem = null;
            EndMondayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox2 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox2_Checked(object sender, RoutedEventArgs e)
        {
            StartMondayHour.SelectedItem = "00";
            StartMondayMinute.SelectedItem = "00";
            EndMondayHour.SelectedItem = "00";
            EndMondayMinute.SelectedItem = "00";
        }

        /// <summary>
        /// event when CheckBox3 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox3_Unchecked(object sender, RoutedEventArgs e)
        {
            StartTuesdayHour.SelectedItem = null;
            StartTuesdayMinute.SelectedItem = null;
            EndTuesdayHour.SelectedItem = null;
            EndTuesdayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox3 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox3_Checked(object sender, RoutedEventArgs e)
        {
            StartTuesdayHour.SelectedItem = "00";
            StartTuesdayMinute.SelectedItem = "00";
            EndTuesdayHour.SelectedItem = "00";
            EndTuesdayMinute.SelectedItem = "00";
        }

        /// <summary>
        /// event when CheckBox4 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox4_Unchecked(object sender, RoutedEventArgs e)
        {
            StartWednesdayHour.SelectedItem = null;
            StartWednesdayMinute.SelectedItem = null;
            EndWednesdayHour.SelectedItem = null;
            EndWednesdayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox4 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox4_Checked(object sender, RoutedEventArgs e)
        {
            StartWednesdayHour.SelectedItem = "00";
            StartWednesdayMinute.SelectedItem = "00";
            EndWednesdayHour.SelectedItem = "00";
            EndWednesdayMinute.SelectedItem = "00";
        }

        /// <summary>
        /// event when CheckBox5 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox5_Unchecked(object sender, RoutedEventArgs e)
        {
            StartThursdayHour.SelectedItem = null;
            StartThursdayMinute.SelectedItem = null;
            EndThursdayHour.SelectedItem = null;
            EndThursdayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox5 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox5_Checked(object sender, RoutedEventArgs e)
        {
            StartThursdayHour.SelectedItem = "00";
            StartThursdayMinute.SelectedItem = "00";
            EndThursdayHour.SelectedItem = "00";
            EndThursdayMinute.SelectedItem = "00";
        }

        /// <summary>
        /// event when CheckBox6 Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox6_Unchecked(object sender, RoutedEventArgs e)
        {
            StartFridayHour.SelectedItem = null;
            StartFridayMinute.SelectedItem = null;
            EndFridayHour.SelectedItem = null;
            EndFridayMinute.SelectedItem = null;
        }

        /// <summary>
        /// event when CheckBox6 checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox6_Checked(object sender, RoutedEventArgs e)
        {
            StartFridayHour.SelectedItem = "00";
            StartFridayMinute.SelectedItem = "00";
            EndFridayHour.SelectedItem = "00";
            EndFridayMinute.SelectedItem = "00";
        }


    }



    /// <summary>
    /// converter, convert true to 00, false to null (for the binding of checkbox to comboboxes of the time
    /// </summary>
    public class NotBooleanToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool boolValue = (bool)value;
            if (boolValue) { return "00"; }
            else { return null; }
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        { throw new NotImplementedException(); }

    }

    



}

