﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BL;
using BE;
using System.Globalization;
using System.Threading;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MothersWindow.xaml
    /// </summary>
    public partial class MothersWindow : Window
    {
        IBL bl;
        Mother motherToAdd;
        Mother motherToUpdate;
        private List<string> AddErrorMessages;
        private List<string> UpdateErrorMessages;
        public MothersWindow()
        {
            try
            {
                InitializeComponent();
                bl = FactoryBL.GetBL();
                motherToAdd = new Mother();
                AddMotherGrid.DataContext = motherToAdd;
                motherToUpdate = new Mother();
                AddErrorMessages = new List<string>();
                UpdateErrorMessages = new List<string>();
                UpdateMotherGrid.DataContext = motherToUpdate;
                refreshUpdate();
                refreshDelete();
                refreshPersonalSpace();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }

        }
        void refreshDelete()//refresh delete tab 
        {
            DeleteComboBox.ItemsSource = null;
            DeleteComboBox.ItemsSource = bl.GetAllMother();
            DeleteComboBox.DisplayMemberPath = "MotherDetails";
        }

        void refreshUpdate()//refresh update tab 
        {
            idComboBox.ItemsSource = null;
            idComboBox.ItemsSource = bl.GetAllMother();
            idComboBox.DisplayMemberPath = "MotherDetails";
            UpdateExpender.IsExpanded = false;
            addressTextBox.Text = "";
            addressForNannyTextBox.Text = "";

        }

        void refreshPersonalSpace()////refresh personal space tab 
        {
            ChooseMotherComboBox.ItemsSource = null;
            ChooseMotherComboBox.ItemsSource = bl.GetAllMother();
            ChooseMotherComboBox.DisplayMemberPath = "MotherDetails";
        }
        private void DeleteMotherButton_Click(object sender, RoutedEventArgs e)//delete mother click
        {
            try
            {
                if (((Mother)(DeleteComboBox.SelectedItem)) == null)//the user choose a mother to deletein the combo box
                {
                    throw new Exception("must select Mother First ");
                }
                MessageBoxResult result = MessageBox.Show((bl.GetMother(((Mother)(DeleteComboBox.SelectedItem)).Id).ToString()) +
                                             "\nAre you sure you want to delete this mother?\n", "Warnning!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)//if the user wants to delete the mother that he chose
                               //remove the mother
                {
                    case MessageBoxResult.Yes:
                        bl.RemoveMother(((Mother)(DeleteComboBox.SelectedItem)).Id);
                        MessageBox.Show("the Mother removed");
                        refreshDelete();
                        refreshUpdate();
                        refreshPersonalSpace();
                        userControlUpdateMother.RefreshAll();
                        break;
                    default://else
                        break;
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)//add mother click
        {
            try
            {
                //check for every day if the user wants this day,
                //if yes, it taks this details to the mother hour table that will be added
                if (userControlAddMother.CheckBox1.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[0] = true;
                    motherToAdd.wantedWorkHours[0, 0] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartSundayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartSundayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 0] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndSundayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndSundayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddMother.CheckBox2.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[1] = true;
                    motherToAdd.wantedWorkHours[0, 1] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartMondayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartMondayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 1] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndMondayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndMondayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddMother.CheckBox3.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[2] = true;
                    motherToAdd.wantedWorkHours[0, 2] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartTuesdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartTuesdayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 2] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndTuesdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndTuesdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddMother.CheckBox4.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[3] = true;
                    motherToAdd.wantedWorkHours[0, 3] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartWednesdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartWednesdayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 3] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndWednesdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndWednesdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddMother.CheckBox5.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[4] = true;
                    motherToAdd.wantedWorkHours[0, 4] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartThursdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartThursdayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 4] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndThursdayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndThursdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddMother.CheckBox6.IsChecked == true)
                {
                    motherToAdd.needKeepingDays[5] = true;
                    motherToAdd.wantedWorkHours[0, 5] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.StartFridayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.StartFridayMinute.SelectedItem.ToString()), 0);
                    motherToAdd.wantedWorkHours[1, 5] = new DateTime(2000, 1, 1, int.Parse(userControlAddMother.EndFridayHour.SelectedItem.ToString()), int.Parse(userControlAddMother.EndFridayMinute.SelectedItem.ToString()), 0);
                }

                bl.AddMother(motherToAdd);

                MessageBox.Show("the mother is added");

                //refresh
                motherToAdd = new BE.Mother();
                AddMotherGrid.DataContext = motherToAdd;
                refreshDelete();
                refreshUpdate();
                refreshPersonalSpace();
                userControlAddMother.RefreshAll();
                AddExpender.IsExpanded = false;
              
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private Mother getCopy(Mother mother)//copies mother (by value copy)
        {
            if (mother == null)
                return null;
            bool[] days = new bool[6];
            for (int i = 0; i < 6; i++)
            {
                days[i] = mother.needKeepingDays[i];
            }
            DateTime[,] hours = new DateTime[2, 6];
            for (int i = 0; i < 6; i++)
            {
                hours[0, i] = mother.wantedWorkHours[0, i];
                hours[1, i] = mother.wantedWorkHours[1, i];
            }
            return (new Mother()
            {
                Id = mother.Id,
                FirstName = mother.FirstName,
                LastName = mother.LastName,
                Phone = mother.Phone,
                Address = mother.Address,
                AddressForNanny = mother.AddressForNanny,
                needKeepingDays = days,
                wantedWorkHours = hours,
                Comments = mother.Comments,
                mailAddress=mother.mailAddress

            });
        }
        private string timeToString(int num)//convert number to 2 digit number (with 0 if there is a need)
        {
            if (num < 10)
                return ("0" + num);
            return num.ToString();
        }


        private void idComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //selection change event of the combo box of the update
        //where the user selects a mother, it puts his details on the window
        {
            Mother m = idComboBox.SelectedItem as Mother;
            try
            {   
                if (m != null)
                {
                    motherToUpdate = getCopy(m);
                    UpdateMotherGrid.DataContext = motherToUpdate;

                    //check for every day if the user the selected mother wanted this day,
                    //if yes, it puts this details in the userControlUpdateMother (to the screen)
                    if (motherToUpdate.needKeepingDays[0])
                    {
                        userControlUpdateMother.CheckBox1.IsChecked = true;
                        userControlUpdateMother.StartSundayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 0].Hour);
                        userControlUpdateMother.StartSundayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 0].Minute);
                        userControlUpdateMother.EndSundayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 0].Hour);
                        userControlUpdateMother.EndSundayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 0].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[0])
                    {
                        userControlUpdateMother.CheckBox1.IsChecked = false;
                    }

                    if (motherToUpdate.needKeepingDays[1])
                    {
                        userControlUpdateMother.CheckBox2.IsChecked = true;
                        userControlUpdateMother.StartMondayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 1].Hour);
                        userControlUpdateMother.StartMondayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 1].Minute);
                        userControlUpdateMother.EndMondayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 1].Hour);
                        userControlUpdateMother.EndMondayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 1].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[1])
                    {
                        userControlUpdateMother.CheckBox2.IsChecked = false;
                    }

                    if (motherToUpdate.needKeepingDays[2])
                    {
                        userControlUpdateMother.CheckBox3.IsChecked = true;
                        userControlUpdateMother.StartTuesdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 2].Hour);
                        userControlUpdateMother.StartTuesdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 2].Minute);
                        userControlUpdateMother.EndTuesdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 2].Hour);
                        userControlUpdateMother.EndTuesdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 2].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[2])
                    {
                        userControlUpdateMother.CheckBox3.IsChecked = false;
                    }

                    if (motherToUpdate.needKeepingDays[3])
                    {
                        userControlUpdateMother.CheckBox4.IsChecked = true;
                        userControlUpdateMother.StartWednesdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 3].Hour);
                        userControlUpdateMother.StartWednesdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 3].Minute);
                        userControlUpdateMother.EndWednesdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 3].Hour);
                        userControlUpdateMother.EndWednesdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 3].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[3])
                    {
                        userControlUpdateMother.CheckBox4.IsChecked = false;
                    }

                    if (motherToUpdate.needKeepingDays[4])
                    {
                        userControlUpdateMother.CheckBox5.IsChecked = true;
                        userControlUpdateMother.StartThursdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 4].Hour);
                        userControlUpdateMother.StartThursdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 4].Minute);
                        userControlUpdateMother.EndThursdayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 4].Hour);
                        userControlUpdateMother.EndThursdayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 4].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[4])
                    {
                        userControlUpdateMother.CheckBox5.IsChecked = false;
                    }
                    if (motherToUpdate.needKeepingDays[5])
                    {
                        userControlUpdateMother.CheckBox6.IsChecked = true;
                        userControlUpdateMother.StartFridayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 5].Hour);
                        userControlUpdateMother.StartFridayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[0, 5].Minute);
                        userControlUpdateMother.EndFridayHour.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 5].Hour);
                        userControlUpdateMother.EndFridayMinute.SelectedItem = timeToString(motherToUpdate.wantedWorkHours[1, 5].Minute);
                    }
                    if (!motherToUpdate.needKeepingDays[5])
                    {
                        userControlUpdateMother.CheckBox6.IsChecked = false;
                    }
                    UpdateExpender.IsExpanded = true;
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)//update click
        {
            try
            {
                if (motherToUpdate != null)//the user selected mother to update
                {
                    //check for every day if the user wants this day,
                    //if yes, it takes this details to the mother hour table that will be updated
                    for (int i = 0; i < 6; i++)
                    {
                        motherToUpdate.needKeepingDays[i] = false;
                    }

                    if (userControlUpdateMother.CheckBox1.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[0] = true;
                        motherToUpdate.wantedWorkHours[0, 0] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartSundayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartSundayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 0] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndSundayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndSundayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateMother.CheckBox2.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[1] = true;
                        motherToUpdate.wantedWorkHours[0, 1] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartMondayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartMondayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 1] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndMondayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndMondayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateMother.CheckBox3.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[2] = true;
                        motherToUpdate.wantedWorkHours[0, 2] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartTuesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartTuesdayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 2] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndTuesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndTuesdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateMother.CheckBox4.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[3] = true;
                        motherToUpdate.wantedWorkHours[0, 3] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartWednesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartWednesdayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 3] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndWednesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndWednesdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateMother.CheckBox5.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[4] = true;
                        motherToUpdate.wantedWorkHours[0, 4] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartThursdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartThursdayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 4] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndThursdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndThursdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateMother.CheckBox6.IsChecked == true)
                    {
                        motherToUpdate.needKeepingDays[5] = true;
                        motherToUpdate.wantedWorkHours[0, 5] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.StartFridayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.StartFridayMinute.SelectedItem.ToString()), 0);
                        motherToUpdate.wantedWorkHours[1, 5] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateMother.EndFridayHour.SelectedItem.ToString()), int.Parse(userControlUpdateMother.EndFridayMinute.SelectedItem.ToString()), 0);
                    }
                    bl.UpdateMother(motherToUpdate);

                    this.DeleteComboBox.ItemsSource = null;//refresh

                    IEnumerable<Contract> temp = bl.GetAllContract(co => bl.GetChild(co.IdChild).IdMother == motherToUpdate.Id);//get all the contract of this mother
                    if (temp.ToList().Count!=0)//if she has a contracts, tell the user to pay attention
                        MessageBox.Show("the Mother is updated\nPay Attention-the contracts of this monther are not update too!");
                    else
                        MessageBox.Show("the Mother is updated");
                    
                    //refresh
                    motherToUpdate = new Mother();
                    UpdateMotherGrid.DataContext = motherToUpdate;
                    userControlUpdateMother.RefreshAll();
                    refreshDelete();
                    refreshUpdate();
                    refreshPersonalSpace();

                }
                else
                    throw new Exception("must select mother first");
            }
            catch (Exception E)
            {

                MessageBox.Show(E.Message);
            }
        }
        public void Act(List<Nanny> grouping)//func for the thread
        {
            try
            {
                UserControlGetAll groupingUser = new UserControlGetAll();
                groupingUser.label.Content = "All The closing Nannies:";
                this.page.Content = groupingUser;
                groupingUser.listView.ItemsSource = grouping;
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        private void BestCloseButton_Click(object sender, RoutedEventArgs e)//best close nanny click
        {
            try
            {
                Mother helpMother = (ChooseMotherComboBox.SelectedItem) as Mother;
                if (ChooseMotherComboBox.SelectedItem != null)//if the user selected a mother
                { 
                    Thread t = new Thread(//creates the thread
                    () =>
                    {
                        var v = bl.getCloseNannies(helpMother);
                        Action<List<Nanny>> a = Act;
                        Dispatcher.BeginInvoke(a, v.ToList());
                    });
                    t.Start();//starts the thread
                }
                else
                    throw new Exception("must select mother first");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AllChildrenButton_Click(object sender, RoutedEventArgs e)//get all the childrean of the selected mother to the screen
        {
            try
            {
                if (ChooseMotherComboBox.SelectedItem != null)//the user selected a mother
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Children:";
                    this.page.Content = groupingUser;
                    Mother helpMother = (ChooseMotherComboBox.SelectedItem) as Mother;
                    groupingUser.listView.ItemsSource = bl.GetAllChild(ch => ch.IdMother == helpMother.Id);
                }
                else
                    throw new Exception("must select mother first");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
       

        }

        private void AllContractsButton_Click(object sender, RoutedEventArgs e)//show all the contract of the mother that selected
        {
            try
            {
                if (ChooseMotherComboBox.SelectedItem != null)
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Contract that the mother is in:";
                    this.page.Content = groupingUser;
                    Mother helpMother = (ChooseMotherComboBox.SelectedItem) as Mother;
                    groupingUser.listView.ItemsSource = bl.getAllContractAccordingDelegate(co=>bl.GetChild(co.IdChild).IdMother==helpMother.Id);
                }
                else
                    throw new Exception("must select mother first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BestMatchButton_Click(object sender, RoutedEventArgs e)//show the user best match (by hour), to the selected mother
        {
            try
            {
                if (ChooseMotherComboBox.SelectedItem != null)//if the user selected a mother
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Best Match Nannies:";
                    this.page.Content = groupingUser;

                    groupingUser.listView.ItemsSource = bl.get5BestMatchNannies((ChooseMotherComboBox.SelectedItem) as Mother);
                }
                else
                    throw new Exception("must select mother first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Add_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                AddErrorMessages.Add(e.Error.Exception.Message);
            else
                AddErrorMessages.Remove(e.Error.Exception.Message);
            this.AddButton.IsEnabled = !AddErrorMessages.Any();
        }

        private void Update_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                UpdateErrorMessages.Add(e.Error.Exception.Message);
            else
                UpdateErrorMessages.Remove(e.Error.Exception.Message);
            this.UpdateButton.IsEnabled = !UpdateErrorMessages.Any();
        }

        private void RateNanniesButton_Click(object sender, RoutedEventArgs e)//show the user all the nanny that the selected
            //mother has a contract with them, and it gives option to rate them 
        {
            try
            {
                if (ChooseMotherComboBox.SelectedItem != null)
                {
                    UserControlGetAllNannyRate groupingUser = new UserControlGetAllNannyRate();
                    groupingUser.label.Content = "Rate Nannies:";
                    this.page.Content = groupingUser;
                    Mother helpMother = (ChooseMotherComboBox.SelectedItem) as Mother;
                    IEnumerable<Contract> temp = bl.GetAllContract(co => bl.GetChild(co.IdChild).IdMother == helpMother.Id);
                    List<Nanny> lst = new List<Nanny>();
                    foreach (var item in temp)//add all the nannies that have contract with the mother to lst
                    {
                        lst.Add(bl.GetNanny(item.IdNanny));
                    }
                    
                    for (int i = 0; i < lst.Count; i++)//delete all the double nannies from lst
                    {
                        int count = 0;
                        for (int j = 0; j < lst.Count; j++)
                        {
                            if (lst[i]==lst[j])
                            count++;
                        }
                        if (count > 1)
                            lst.RemoveAt(i);
                    }
                    groupingUser.listView.ItemsSource =lst;
                }
                else
                    throw new Exception("must select mother first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ChooseMotherComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//refresh the screen in every selection in the personal space tab
        {
            page.Content = new UserControlGetAll();
        }
    }
}
