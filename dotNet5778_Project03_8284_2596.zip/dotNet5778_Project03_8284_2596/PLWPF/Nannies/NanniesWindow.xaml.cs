﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;
using System.Threading;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for NanniesWindow.xaml
    /// </summary>
    public partial class NanniesWindow : Window
    {
        IBL bl;
        Nanny nannyToAdd;
        Nanny nannyToUpdate;
        private List<string> AddErrorMessages;
        private List<string> UpdateErrorMessages;
        public NanniesWindow()
        {
            try
            {
                InitializeComponent();
                bl = FactoryBL.GetBL();
                nannyToAdd = new Nanny();
                nannyToAdd.BirthDate = DateTime.Now;
                AddNannyGrid.DataContext = nannyToAdd;
                nannyToUpdate = new Nanny();
                nannyToUpdate.BirthDate = DateTime.Now;
                AddErrorMessages = new List<string>();
                UpdateErrorMessages = new List<string>();
                UpdateNannyGrid.DataContext = nannyToUpdate;
                refreshUpdate();
                refreshDelete();
                refreshPersonalSpace();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        void refreshDelete()//refresh delete tab
        {
            DeleteComboBox.ItemsSource = null;
            DeleteComboBox.ItemsSource = bl.GetAllNanny();
            DeleteComboBox.DisplayMemberPath = "NannyDetails";
        }

        void refreshUpdate()//refresh update tab
        {
            idComboBox1.ItemsSource = null;
            idComboBox1.ItemsSource = bl.GetAllNanny();
            idComboBox1.DisplayMemberPath = "NannyDetails";
            UpdateExpender.IsExpanded = false;

        }
        void refreshPersonalSpace()//refresh personal space tab
        {
            ChooseNannyComboBox.ItemsSource = null;
            ChooseNannyComboBox.ItemsSource = bl.GetAllNanny();
            ChooseNannyComboBox.DisplayMemberPath = "NannyDetails";
        }
        private void DeleteNannyButton_Click(object sender, RoutedEventArgs e)//delete nanny click
        {
            try
            {
                if (((Nanny)(DeleteComboBox.SelectedItem)) == null)//the user choose a nanny to delete in the combo box
                {
                    throw new Exception("must select nanny First ");
                }
                MessageBoxResult result = MessageBox.Show((bl.GetNanny(((Nanny)(DeleteComboBox.SelectedItem)).Id).ToString()) +
                                            "\nAre you sure you want to delete this nanny?\n", "Warnning!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes://if the user wants to delete the nanny that he chose
                                              //remove the nanny
                        bl.RemoveNanny(((Nanny)(DeleteComboBox.SelectedItem)).Id);
                        MessageBox.Show("the nanny removed");
                        refreshDelete();
                        refreshUpdate();
                        refreshPersonalSpace();
                        userControlUpdateNanny.RefreshAll();
                        break;
                    default://else
                        break;
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)//add nanny click
        {
            try
            {
                //check for every day if the user wants this day,
                //if yes, it taks this details to the nanny hour table that will be added
                if (userControlAddNanny.CheckBox1.IsChecked == true)
                {
                    nannyToAdd.keepingDays[0] = true;
                    nannyToAdd.workHours[0, 0] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartSundayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartSundayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 0] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndSundayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndSundayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddNanny.CheckBox2.IsChecked == true)
                {
                    nannyToAdd.keepingDays[1] = true;
                    nannyToAdd.workHours[0, 1] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartMondayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartMondayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 1] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndMondayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndMondayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddNanny.CheckBox3.IsChecked == true)
                {
                    nannyToAdd.keepingDays[2] = true;
                    nannyToAdd.workHours[0, 2] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartTuesdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartTuesdayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 2] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndTuesdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndTuesdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddNanny.CheckBox4.IsChecked == true)
                {
                    nannyToAdd.keepingDays[3] = true;
                    nannyToAdd.workHours[0, 3] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartWednesdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartWednesdayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 3] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndWednesdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndWednesdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddNanny.CheckBox5.IsChecked == true)
                {
                    nannyToAdd.keepingDays[4] = true;
                    nannyToAdd.workHours[0, 4] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartThursdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartThursdayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 4] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndThursdayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndThursdayMinute.SelectedItem.ToString()), 0);
                }
                if (userControlAddNanny.CheckBox6.IsChecked == true)
                {
                    nannyToAdd.keepingDays[5] = true;
                    nannyToAdd.workHours[0, 5] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.StartFridayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.StartFridayMinute.SelectedItem.ToString()), 0);
                    nannyToAdd.workHours[1, 5] = new DateTime(2000, 1, 1, int.Parse(userControlAddNanny.EndFridayHour.SelectedItem.ToString()), int.Parse(userControlAddNanny.EndFridayMinute.SelectedItem.ToString()), 0);
                }

                bl.AddNanny(nannyToAdd);
             
                MessageBox.Show("the nanny is added");

                //refresh
                nannyToAdd = new BE.Nanny();
                nannyToAdd.BirthDate = DateTime.Now;
                AddNannyGrid.DataContext = nannyToAdd;
                refreshDelete();
                refreshUpdate();
                refreshPersonalSpace();
                userControlAddNanny.RefreshAll();
                AddExpender.IsExpanded = false;
               
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private Nanny getCopy(Nanny nanny)//copies nanny by value copy
        {
            if (nanny == null)
                return null;
            bool[] days = new bool[6];
            for (int i = 0; i < 6; i++)
            {
                days[i] = nanny.keepingDays[i];
            }
            DateTime[,] hours = new DateTime[2, 6];
            for (int i = 0; i < 6; i++)
            {
                hours[0, i] = nanny.workHours[0, i];
                hours[1, i] = nanny.workHours[1, i];
            }
            return (new Nanny()
            {
                Id = nanny.Id,
                FirstName = nanny.FirstName,
                LastName = nanny.LastName,
                BirthDate = nanny.BirthDate,
                Phone = nanny.Phone,
                Address = nanny.Address,
                Elevator = nanny.Elevator,
                Floor = nanny.Floor,
                ExperienceYears = nanny.ExperienceYears,
                NumOfChildren = nanny.NumOfChildren,
                MaxChildrens = nanny.MaxChildrens,
                MinMonthesAge = nanny.MinMonthesAge,
                MaxMonthesAge = nanny.MaxMonthesAge,
                BoolMoneyForHour = nanny.BoolMoneyForHour,
                MoneyForHour = nanny.MoneyForHour,
                MoneyForMonth = nanny.MoneyForMonth,
                keepingDays = days,
                workHours = hours,
                VacationByEducationOffice = nanny.VacationByEducationOffice,
                Recommendations = nanny.Recommendations,
                mailAddress = nanny.mailAddress,
                Rate=nanny.Rate
            });
        }
        private string timeToString(int num)//convert 1 digit number to 2 digit numbers (with 0)
        {
            if (num < 10)
                return ("0" + num);
            return num.ToString();
        }

        
        private void idComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //selection change event of the combo box of the update
        //where the user selects a nanny, it puts his details on the window
        {
            Nanny n = idComboBox1.SelectedItem as Nanny;
            try
            {
                if (n != null)
                {
                    nannyToUpdate = getCopy(n);
                    UpdateNannyGrid.DataContext = nannyToUpdate;

                    //check for every day if the user the selected nanny wanted this day,
                    //if yes, it puts this details in the userControlUpdateNanny (to the screen)
                    if (nannyToUpdate.keepingDays[0])
                    {
                        userControlUpdateNanny.CheckBox1.IsChecked = true;
                        userControlUpdateNanny.StartSundayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 0].Hour);
                        userControlUpdateNanny.StartSundayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 0].Minute);
                        userControlUpdateNanny.EndSundayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 0].Hour);
                        userControlUpdateNanny.EndSundayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 0].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[0])
                    {
                        userControlUpdateNanny.CheckBox1.IsChecked = false;
                    }

                    if (nannyToUpdate.keepingDays[1])
                    {
                        userControlUpdateNanny.CheckBox2.IsChecked = true;
                        userControlUpdateNanny.StartMondayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 1].Hour);
                        userControlUpdateNanny.StartMondayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 1].Minute);
                        userControlUpdateNanny.EndMondayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 1].Hour);
                        userControlUpdateNanny.EndMondayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 1].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[1])
                    {
                        userControlUpdateNanny.CheckBox2.IsChecked = false;
                    }

                    if (nannyToUpdate.keepingDays[2])
                    {
                        userControlUpdateNanny.CheckBox3.IsChecked = true;
                        userControlUpdateNanny.StartTuesdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 2].Hour);
                        userControlUpdateNanny.StartTuesdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 2].Minute);
                        userControlUpdateNanny.EndTuesdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 2].Hour);
                        userControlUpdateNanny.EndTuesdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 2].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[2])
                    {
                        userControlUpdateNanny.CheckBox3.IsChecked = false;
                    }

                    if (nannyToUpdate.keepingDays[3])
                    {
                        userControlUpdateNanny.CheckBox4.IsChecked = true;
                        userControlUpdateNanny.StartWednesdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 3].Hour);
                        userControlUpdateNanny.StartWednesdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 3].Minute);
                        userControlUpdateNanny.EndWednesdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 3].Hour);
                        userControlUpdateNanny.EndWednesdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 3].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[3])
                    {
                        userControlUpdateNanny.CheckBox4.IsChecked = false;
                    }

                    if (nannyToUpdate.keepingDays[4])
                    {
                        userControlUpdateNanny.CheckBox5.IsChecked = true;
                        userControlUpdateNanny.StartThursdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 4].Hour);
                        userControlUpdateNanny.StartThursdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 4].Minute);
                        userControlUpdateNanny.EndThursdayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 4].Hour);
                        userControlUpdateNanny.EndThursdayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 4].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[4])
                    {
                        userControlUpdateNanny.CheckBox5.IsChecked = false;
                    }
                    if (nannyToUpdate.keepingDays[5])
                    {
                        userControlUpdateNanny.CheckBox6.IsChecked = true;
                        userControlUpdateNanny.StartFridayHour.SelectedItem = timeToString(nannyToUpdate.workHours[0, 5].Hour);
                        userControlUpdateNanny.StartFridayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[0, 5].Minute);
                        userControlUpdateNanny.EndFridayHour.SelectedItem = timeToString(nannyToUpdate.workHours[1, 5].Hour);
                        userControlUpdateNanny.EndFridayMinute.SelectedItem = timeToString(nannyToUpdate.workHours[1, 5].Minute);
                    }
                    if (!nannyToUpdate.keepingDays[5])
                    {
                        userControlUpdateNanny.CheckBox6.IsChecked = false;
                    }

                    UpdateExpender.IsExpanded = true;//open the expender 
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)//update click
        {
            try
            {
                if (idComboBox1.SelectedItem == null)
                    throw new Exception("must select nanny first!");

                //check for every day if the user wants this day,
                //if yes, it takes this details to the nanny hour table that will be updated
                if (nannyToUpdate != null)
                {
                    for (int i = 0; i < 6; i++)
                    {
                        nannyToUpdate.keepingDays[i] = false;
                    }

                    if (userControlUpdateNanny.CheckBox1.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[0] = true;
                        nannyToUpdate.workHours[0, 0] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartSundayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartSundayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 0] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndSundayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndSundayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateNanny.CheckBox2.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[1] = true;
                        nannyToUpdate.workHours[0, 1] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartMondayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartMondayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 1] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndMondayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndMondayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateNanny.CheckBox3.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[2] = true;
                        nannyToUpdate.workHours[0, 2] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartTuesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartTuesdayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 2] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndTuesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndTuesdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateNanny.CheckBox4.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[3] = true;
                        nannyToUpdate.workHours[0, 3] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartWednesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartWednesdayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 3] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndWednesdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndWednesdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateNanny.CheckBox5.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[4] = true;
                        nannyToUpdate.workHours[0, 4] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartThursdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartThursdayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 4] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndThursdayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndThursdayMinute.SelectedItem.ToString()), 0);
                    }
                    if (userControlUpdateNanny.CheckBox6.IsChecked == true)
                    {
                        nannyToUpdate.keepingDays[5] = true;
                        nannyToUpdate.workHours[0, 5] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.StartFridayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.StartFridayMinute.SelectedItem.ToString()), 0);
                        nannyToUpdate.workHours[1, 5] = new DateTime(2000, 1, 1, int.Parse(userControlUpdateNanny.EndFridayHour.SelectedItem.ToString()), int.Parse(userControlUpdateNanny.EndFridayMinute.SelectedItem.ToString()), 0);
                    }
                    bl.UpdateNanny(nannyToUpdate);

                    this.DeleteComboBox.ItemsSource = null;


                    IEnumerable<Contract> temp = bl.GetAllContract(co => co.IdNanny == nannyToUpdate.Id);//get all the contracts that the nanny is in them
                    if (temp.ToList().Count != 0)//if she has a contracts, tell the user to pay attention
                        MessageBox.Show("the nanny is updated\nPay Attention-the contracts of this nanny are not update too!");
                    else
                        MessageBox.Show("the nanny is updated");

                    //refresh
                    nannyToUpdate = new Nanny();
                    nannyToUpdate.BirthDate = DateTime.Now;
                    UpdateNannyGrid.DataContext = nannyToUpdate;
                    userControlUpdateNanny.RefreshAll();
                    refreshDelete();
                    refreshUpdate();
                    refreshPersonalSpace();
                }
            }
            catch (Exception E)
            {

                MessageBox.Show(E.Message);
            }
        }

        private void AllChildrenButton_Click(object sender, RoutedEventArgs e)
            //get all the children of the selected nanny and it show (to the screen)
        {
            try
            {
                if (ChooseNannyComboBox.SelectedItem != null)
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Children that have a contract with\n the nanny:";
                    this.page.Content = groupingUser;
                    Nanny helpNanny = (ChooseNannyComboBox.SelectedItem) as Nanny;
                    groupingUser.listView.ItemsSource = bl.GetAllChildOfNanny(helpNanny);
                }
                else
                    throw new Exception("must select Nanny first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void SpecialNeedsButton_Click(object sender, RoutedEventArgs e)
        //get all the special needs of the children of the selected nanny and it show them(to the screen)
        {
            try
            {
                if (ChooseNannyComboBox.SelectedItem != null)
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All the special needs:";
                    this.page.Content = groupingUser;
                    Nanny helpNanny = (ChooseNannyComboBox.SelectedItem) as Nanny;
                    List<string> lst = new List<string>();
                    lst.Add(bl.ChildSpecialNeeds(helpNanny));
                    groupingUser.listView.ItemsSource = lst;
                    groupingUser.listView.FontSize = 16;
                }
                else
                    throw new Exception("must select Nanny first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CommentsButton_Click(object sender, RoutedEventArgs e)
             //get all the comments of all the mothers that have a contract with the selected nanny and it show (to the screen)
        {
            try
            {
                if (ChooseNannyComboBox.SelectedItem != null)
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Comments of the mothers for nanny:";
                    this.page.Content = groupingUser;
                    Nanny helpNanny = (ChooseNannyComboBox.SelectedItem) as Nanny;
                    List<string> lst=new List<string>();
                    lst.Add(bl.MothersComments(helpNanny));
                    groupingUser.listView.ItemsSource = lst;
                    groupingUser.listView.FontSize = 16;
                }
                else
                    throw new Exception("must select Nanny first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BirthDayChildrenButton_Click(object sender, RoutedEventArgs e)
        //get groping of the children of the selected nanny, that have a birthdate in this month, and group it by the day of the month
        //and it show (to the screen)
        {
            try
            {
                if (ChooseNannyComboBox.SelectedItem != null)
                {
                    UserControlGrouping groupingUser = new UserControlGrouping();
                    groupingUser.label.Content = "All Children that have a contract with the nanny\n and have a Birthday this month:";
                    groupingUser.label.FontSize = 20;
                    this.page.Content = groupingUser;
                    Nanny helpNanny = (ChooseNannyComboBox.SelectedItem) as Nanny;
                    groupingUser.listView.ItemsSource = bl.getAllMonthBirthdayChild(helpNanny);
                }
                else
                    throw new Exception("must select Nanny first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PhoneNumbersButton_Click(object sender, RoutedEventArgs e)
        //get all the phone numbers of all the mothers that have a contract with the selected nanny and it show them(to the screen)
        {
            try
            {
                if (ChooseNannyComboBox.SelectedItem != null)
                {
                    UserControlGetAll groupingUser = new UserControlGetAll();
                    groupingUser.label.Content = "All Phone numbers of the mothers:";
                    this.page.Content = groupingUser;
                    Nanny helpNanny = (ChooseNannyComboBox.SelectedItem) as Nanny;
                    List<string> lst = new List<string>();
                    lst.Add(bl.MothersPhones(helpNanny));
                    groupingUser.listView.ItemsSource = lst;
                    groupingUser.listView.FontSize = 16;
                }
                else
                    throw new Exception("must select Nanny first");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Act(List<Nanny> result)//the func that will be run from the thread
        {
            try
            {
                UserControlGetAll nannyDistance = new UserControlGetAll();
                this.searchPage.Content = nannyDistance;
                if (SearchHourCheck.IsChecked == true || SearchMonthCheck.IsChecked == true)//find nanny by distance and by price too
                {
                    float help;
                    if (SearchPrice.Text != null && SearchPrice.Text != "")
                        help = float.Parse(SearchPrice.Text);
                    else
                        throw new Exception("must write price value");
                    List<Nanny> lst = new List<Nanny>();
                    if (SearchHourCheck.IsChecked == true)//by hour
                    {
                        for (int i = 0; i < result.Count; i++)//give all the nanny that their price is less from the wanted price
                        {
                            if (result[i].BoolMoneyForHour == true && result[i].MoneyForHour <= help)
                                lst.Add(result[i]);
                        }
                    }
                    if (SearchMonthCheck.IsChecked == true)//by month
                    {
                        for (int i = 0; i < result.Count; i++)
                        {
                            if (result[i].BoolMoneyForHour == false && result[i].MoneyForMonth <= help)
                                lst.Add(result[i]);
                        }
                    }
                    nannyDistance.Source = lst;
                }
                else
                    nannyDistance.Source = result;
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void SearchNannyButton_Click(object sender, RoutedEventArgs e)
            //find a nanny by the user choose
        {
            try
            {
                if (SearchAddressCheck.IsChecked == false && SearchHourCheck.IsChecked == false && SearchMonthCheck.IsChecked == false)
                    //the user does not choose nothing, show all the nanny
                    searchPage.Source = bl.GetAllNanny();
                if(SearchAddressCheck.IsChecked == true)//by address
                {
                    string s = SearchAddress.Text;
                    float f;
                    if(SearchAddress.Text=="")//no write address
                        throw new Exception("must write address");
                    if (SearchDistance.Text != null && SearchDistance.Text != "")//write the wanted radius
                       f = float.Parse(SearchDistance.Text);
                    else
                        throw new Exception("must write distance value");
                    if (SearchHourCheck.IsChecked == true || SearchMonthCheck.IsChecked == true)//by price
                    {
                        if (SearchPrice.Text == null || SearchPrice.Text == "")
                            throw new Exception("must write price value");
                    }
                        Thread t = new Thread(//cretea a thread to getthe closing nanny
                  () =>
                  {
                      var v = (bl.getDistanceNannies(s,f));
                    Action<List<Nanny>> a = Act;
                      Dispatcher.BeginInvoke(a, v.ToList());
                  });
                    t.Start();

                }
                else//not by distance
                {
                    if (SearchHourCheck.IsChecked == true || SearchMonthCheck.IsChecked == true)
                    {
                        float help;
                        if (SearchPrice.Text != null && SearchPrice.Text != "")
                            help = float.Parse(SearchPrice.Text);
                        else
                            throw new Exception("must write price value");
                        if (SearchHourCheck.IsChecked == true)//by hour
                            searchPage.Source = bl.GetAllNanny(na => na.BoolMoneyForHour == true && na.MoneyForHour <= help);
                        if (SearchMonthCheck.IsChecked == true)//by month
                            searchPage.Source = bl.GetAllNanny(na => na.BoolMoneyForHour == false && na.MoneyForMonth <= help);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Add_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                AddErrorMessages.Add(e.Error.Exception.Message);
            else
                AddErrorMessages.Remove(e.Error.Exception.Message);
            this.AddButton.IsEnabled = !AddErrorMessages.Any();
        }

        private void Update_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                UpdateErrorMessages.Add(e.Error.Exception.Message);
            else
                UpdateErrorMessages.Remove(e.Error.Exception.Message);
            this.UpdateButton.IsEnabled = !UpdateErrorMessages.Any();
        }
    }
}
