﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BE;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UserControlDataTemplateNannyRate.xaml
    /// </summary>
    public partial class UserControlDataTemplateNannyRate : UserControl
    {
        public UserControlDataTemplateNannyRate()
        {
            InitializeComponent();
        }

        private void showDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Nanny nanny = this.DataContext as Nanny;
                MessageBox.Show(nanny.ToString());
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void signContract_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Window help = Application.Current.Windows.OfType<MothersWindow>().FirstOrDefault();
                ContractsWindow c = null;
                foreach (ContractsWindow item in Application.Current.Windows.OfType<ContractsWindow>())
                {
                    c = item;
                }
                if (c != null)
                {
                    //Nanny nanny = this.DataContext as Nanny;
                    //ContractsWindow help = new ContractsWindow();
                    //help.TabControl.SelectedIndex = 2;
                    //help.idNannyComboBox1.SelectedItem = nanny;
                    //help.idChildComboBox1.SelectedItem = c.idChildComboBox1.SelectedItem;
                    //help.startDateDatePicker1.SelectedDate = c.startDateDatePicker1.SelectedDate;
                    //help.endDateDatePicker1.SelectedDate = c.endDateDatePicker1.SelectedDate;
                    //help.boolMeetingCheckBox1.IsChecked = c.boolMeetingCheckBox1.IsChecked;
                    //help.signatureCheckBox1.IsChecked = c.signatureCheckBox1.IsChecked;
                    //c.Close();
                    //help.ShowDialog();
                    Nanny nanny = presentor.DataContext as Nanny;
                    c.TabControl.SelectedIndex = 2;
                    c.idNannyComboBox1.SelectedItem = nanny;
                    help.Close();
                    c.Show();
                }
                if (c == null)
                {
                    Nanny nanny = this.DataContext as Nanny;
                    ContractsWindow help1 = new ContractsWindow();
                    help1.TabControl.SelectedIndex = 2;
                    help1.idNannyComboBox1.SelectedItem = nanny;
                    help1.ShowDialog();
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        private void RateNanny_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Nanny nanny = this.DataContext as Nanny;
                nanny.Rate = (nanny.Rate + ratingUserControl.NumOfStars) / 2;
                ratingUserControl.NumOfStars = 0;
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
    }
}
