﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;


namespace DAL
{
    public interface Idal
    {
        #region Nanny Functions
        /// <summary>
        /// This function get nanny and need to add her for NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny"> The nanny that need to add to NannyList</param>
        void AddNanny(Nanny nanny);
       
        /// <summary>
        /// This function get nanny id and need to remove her from NannyList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the nanny to delete</param>
        /// <returns>True if this nanny delete success</returns>
        bool RemoveNanny(int id);

        /// <summary>
        /// This function get nanny and need to update her in NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny">The nanny that need to update</param>
        void UpdateNanny(Nanny nanny);

        /// <summary>
        /// This function get nanny id and search the nanny in NannyList.
        /// </summary>
        /// <param name="id"> The id of the nanny to search</param>
        /// <returns>The nanny that id it's her id if she exist, else null</returns>
        Nanny GetNanny(int id);
       
        /// <summary>
        /// This function search all the nannies that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the nannies are checked by it</param>
        /// <returns>IEnumerable of all nannies that predicate is true for them</returns>
        IEnumerable<Nanny> GetAllNanny(Func<Nanny, bool> predicate = null);
        #endregion

        #region Mother Functions
        /// <summary>
        /// This function get mother and need to add her for MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to add</param>
        void AddMother(Mother mother);

        /// <summary>
        /// This function get id of mother and need to remove her from MotherList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the mother to delete</param>
        /// <returns>True if this mother delete success</returns>
        bool RemoveMother(int id);

        /// <summary>
        /// This function get mother and need to update her in MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to update</param>
        void UpdateMother(Mother mother);

        /// <summary>
        /// This function get mother id and search that mother in the MotherList.
        /// </summary>
        /// <param name="id">The id of the mother to search</param>
        /// <returns>The mother that id it's her id.if she does not exist it return null</returns>
        Mother GetMother(int id);

        /// <summary>
        /// This function search all the mothers that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the mothers are checked by it</param>
        /// <returns>IEnumerable of all mothers that predicate is true for them </returns>
        IEnumerable<Mother> GetAllMother(Func<Mother, bool> predicate = null);
        #endregion

        #region Child Functions
        /// <summary>
        /// This function get child and need to add him for ChildList only if the details of child legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to add</param>
        void AddChild(Child child);

        /// <summary>
        /// This function get child id and need to delete this child from ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The child to delete</param>
        /// <returns>True if this child delete success</returns>
        bool RemoveChild(int id);

        /// <summary>
        /// This function get child and need to update this child in ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to update</param>
        void UpdateChild(Child child);

        /// <summary>
        /// This function get child id and need to find this child.
        /// </summary>
        /// <param name="id">The id of the child to search</param>
        /// <returns>Child if the child exist. else, null</returns>
        Child GetChild(int id);

        /// <summary>
        /// This function get predicate and need to find all the children that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the children are checked by it</param>
        /// <returns>IEnumerable of all the childrens that the predicate true for them</returns>
        IEnumerable<Child> GetAllChild(Func<Child, bool> predicate = null);
        #endregion

        #region Contract Functions
        /// <summary>
        /// This function get a contract and need to add it to ContractList only if the details of the contract legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to add</param>
        void AddContract(Contract contract);

        /// <summary>
        /// This function get a number of contract and remove this contract from ContractList only if it's legal.else, throw Exception
        /// </summary>
        /// <param name="numOFContract">The number of contract to delete</param>
        /// <returns>True if the contract delete success.else, false</returns>
        bool RemoveContract(int numOFContract);

        /// <summary>
        /// This function get a contract and need to update this contract in ContractList only if this action legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to update(with the new details)</param>
        void UpdateContract(Contract contract);

        /// <summary>
        /// This function get number of contract and search that contract
        /// </summary>
        /// <param name="num">The number of contract to search</param>
        /// <returns>Contract if this contract exist. else, null</returns>
        Contract GetContract(int num);

        /// <summary>
        /// This function get predicate and need to find all the contracts that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts are checked by it</param>
        /// <returns>IEnumerable of all the contracts that the predicate true for them</returns>
        IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicate = null);
        #endregion

    }

}
